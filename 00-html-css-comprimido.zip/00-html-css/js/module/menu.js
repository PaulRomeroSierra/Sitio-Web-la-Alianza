export function menu(){
    const menu = document.querySelector(".IconMenu2");

    let menu_close = `
    <svg xmlns="http://www.w3.org/2000/svg" id="menu__open"  width="24" height="24" 
    viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" 
    stroke-linecap="round" stroke-linejoin="round" 
    class="icon icon-tabler icons-tabler-outline icon-tabler-menu-2">
    <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
    <path d="M4 6l16 0" /><path d="M4 12l16 0" /><path d="M4 18l16 0" />
    </svg>`;

    let menu_open = `
    <svg xmlns="http://www.w3.org/2000/svg" id="menu__open" width="24" height="24" 
    viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" 
    stroke-linecap="round" stroke-linejoin="round" 
    class="icon icon-tabler icons-tabler-outline icon-tabler-x">
    <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
    <path d="M18 6L6 18" />
    <path d="M6 6l12 12" />
    </svg>`;

    let abierto = false;
    menu.addEventListener("click", (e) => {
        menu.innerHTML= abierto ? menu_close : menu_open; 
        abierto = !abierto;
    });
}