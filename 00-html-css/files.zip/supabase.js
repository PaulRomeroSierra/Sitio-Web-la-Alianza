// ============================================================
//  supabase.js  —  Configuración del cliente Supabase
//  ⚠️  Reemplaza los valores con los de tu proyecto en:
//      supabase.com → Settings → API
// ============================================================

const SUPABASE_URL  = 'https://TU_PROJECT_ID.supabase.co';  // 👈 cambia esto
const SUPABASE_KEY  = 'TU_ANON_PUBLIC_KEY';                 // 👈 cambia esto

// Importamos la librería desde CDN (ya debe estar en el <head> del HTML)
const { createClient } = supabase;

export const supabaseClient = createClient(SUPABASE_URL, SUPABASE_KEY);
